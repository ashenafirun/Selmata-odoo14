================================
Picking and Reservation Strategy
================================

* Allows to automatically build optimal picking routes and apply custom reservation options.

|

Changelog
=========

* 1.0.1 (2021-06-21)
    - Optimized algorithm to pick mixed orders  (products and packages together).
    - General bug fixing and improvements.
