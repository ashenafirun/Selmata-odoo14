Reply to Sender
=================

This module updates reply-to header in outgoing e-mails with generic mail address.
