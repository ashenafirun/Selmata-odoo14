# Copyright 2020 VentorTech OU
# License LGPL-3.0 or later (https://www.gnu.org/licenses/lgpl-3.0).

from . import test_check_default_location
from . import test_checking_logotype
from . import test_set_active_view
