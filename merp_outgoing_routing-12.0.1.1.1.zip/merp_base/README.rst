Ventor Base
=========================

Base module that allow relation between Ventor modules

Changelog
---------

12.0.1.2.1 (2021-06-29)
***********************

Added access rights on user's settings fields

12.0.1.2.0 (2021-06-22)
***********************

* Added global menu Ventor Configuration
* Ventor configuration checkboxes added to Operations Types
* Users Ventor Application Settings moved to Ventor Preferences tab
